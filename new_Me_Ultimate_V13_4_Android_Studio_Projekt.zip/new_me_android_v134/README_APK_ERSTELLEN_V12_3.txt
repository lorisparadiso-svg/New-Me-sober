NEW ME ULTIMATE V12.3 - APK BUILD (Windows / Android Studio)

1. Android Studio (aktuelle stabile Ausgabe) installieren.
2. Android SDK Platform 35 und SDK Build-Tools installieren (SDK Manager).
3. ZIP entpacken. In Android Studio den Ordner new_me_android_v123 oeffnen.
4. Gradle-Sync mit Internetzugang abschliessen. Das Projekt nutzt Android Gradle Plugin 8.7.3, Gradle 8.9 und Java 17+.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Ergebnis: app/build/outputs/apk/debug/app-debug.apk
   Alternative: im Projektordner unter Windows PowerShell ./build_apk_windows.ps1 ausfuehren (laedt Gradle 8.9).
7. APK auf dein Android-Geraet kopieren und installieren (gegebenenfalls Installation aus dieser Quelle erlauben).

ACHTUNG BEI DATEN
- V12.3 behaelt die Android applicationId ch.newme.ultimate.
- Ein installiertes Paket mit anderem Signaturschluessel kann NICHT als Update eingespielt werden.
- Debug-APK eines anderen Computers hat oft einen anderen Signaturschluessel!
- Vor JEDEM Wechsel aus der bisherigen App JSON-Backup exportieren.
- Erst nach erfolgreichem Import alte App deinstallieren, da Deinstallation lokale App-Daten loescht.
- Browser/HTML-Daten werden NICHT automatisch in Android-WebView synchronisiert.
- Sichere den Export und importiere ihn in der Android-App ueber die vorhandene Backup-Funktion.
- Die V12.3-App wurde hier NICHT mit Android SDK gebaut oder auf einem Telefon getestet.
