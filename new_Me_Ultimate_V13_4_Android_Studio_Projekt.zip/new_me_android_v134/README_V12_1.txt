V12.1 Ultimate Intelligence. Existing native bridge retained. Compile with Android Studio and validate permissions, reminder notifications and data migration on a physical device.
