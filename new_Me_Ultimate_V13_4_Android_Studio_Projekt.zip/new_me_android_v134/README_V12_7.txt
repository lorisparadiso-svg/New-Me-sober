new Me Ultimate V12.7 LIFE EVOLUTION
====================================================
Open new_me_android_v127 folder (NOT ZIP) in Android Studio.
Build > Build Bundle(s) / APK(s) > Build APK(s).
Output: app/build/outputs/apk/debug/app-debug.apk
Application ID: ch.newme.ultimate (unchanged).
versionCode 130, versionName 12.7.

V12.7 is an additive optional 66 active-day life program using original
life-reset-v1 storage, original tasks, XP ledger, challenge, character and shop.
No additional Android app tabs, app permissions, or replacement storage.
Only optional nm127 object inside existing JSON is created on user action.
Rewards are cosmetic; NO extra XP or shop coins are awarded.
Back key exits program settings before handling pre-existing dialogs.

IMPORTANT: For an upgrade the signing certificate must match your installed
app (a default debug key may be different across PCs). Back up your app first.
No APK was compiled in the supplied execution environment. Build and real
Samsung/Android WebView testing are still needed. See the test report.
