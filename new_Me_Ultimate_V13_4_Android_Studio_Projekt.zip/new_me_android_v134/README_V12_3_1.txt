New Me Ultimate V12.3.1 Tracking-Polish

Statt grauer Android-Standard-Eingabefelder bekommen die Tracking-Eintraege ein einheitliches dunkles Formulardesign.
Bestehende Skripte, Daten und Speicherschluessel wurden unveraendert uebernommen.
App-ID bleibt ch.newme.ultimate, versionCode 124.
Zur APK-Erstellung Android Studio, Ordner new_me_android_v1231 oeffnen und Build > Build APK(s).
Verwendet dieselbe Debugsignatur deines Rechners fuer ein Update. Vorher JSON-Backup empfohlen.
