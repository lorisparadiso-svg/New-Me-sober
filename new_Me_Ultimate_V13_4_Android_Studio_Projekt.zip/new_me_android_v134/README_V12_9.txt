new Me Ultimate V12.9 · Smart Coach & Fitness Pro

Basis: V12.8 Originalprojekt. Bisherige App-ID: ch.newme.ultimate
versionCode 135, versionName 12.9.
Daten bleiben unter life-reset-v1. Kein neues Level- oder Workout-Speicherformat.

Neue Funktionen (im vorhandenen KI-Coach und Workout Studio):
1. Verknüpfte Übersicht aus Tagesmissionen, Fitness und aktiven Trackern.
2. Konkrete Tagesplan-Vorschau mit Bestätigung vor der Übernahme neuer Aufgaben.
3. Selektive Datenauswahl für den bestehenden KI-Chat. Keine automatische Übertragung.
4. Guided Workout nutzt die originale nm75.active Workout-Datenbank.
5. Satz-Logging mit kg, Wdh., RIR und automatischem Start eines Pausentimers.
6. Vorsichtige Progressionshinweise aus historischen Trainingseinheiten.
7. Kein neues XP: Vergabe wie bisher erst beim nativen Workout-Abschluss.

APK erstellen: Android Studio -> Projektordner new_me_android_v129 -> Build -> Build APK(s).
Ausgabepfad: app/build/outputs/apk/debug/app-debug.apk.
Vorher Datenbackup erstellen. Für Updates muss die Signatur zum installierten APK passen.
Teststatus: JS-Syntax, Browser-Interaktionen und ZIP-Integrität geprüft.
Kein echter Android SDK / Gradle Build in der Erstellungsumgebung; Samsung-Test offen.
