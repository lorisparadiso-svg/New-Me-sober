new Me Ultimate V13.0 · Character Evolution

Basis: vollständiges V12.9-Projekt. App-ID bleibt ch.newme.ultimate, Speicherschlüssel bleibt life-reset-v1.
Die 50 eingebetteten Anime-Bilder, ursprünglichen Missionen, XP, Shop, Boss-Missionen und alle Reiter bleiben im HTML enthalten.
Neu: fünf visuelle Evolutionsphasen, Erreichungsanzeige, nächste kosmetische Freischaltung, 7-Tage-Missions-XP, drei lokale Outfit-Speicherplätze und Animationsschalter.
Nur Einstellungen/Ausrüstungssets werden zusätzlich unter nm130 innerhalb des bestehenden Datenobjekts gespeichert.

APK: Ordner new_me_android_v130 in Android Studio öffnen, Gradle-Sync, Build > Build APK(s).
WICHTIG: Alte App nicht deinstallieren; vor dem Update ein Backup erstellen. Das Upgrade erfordert dieselbe APK-Signatur.
Status: Statische Prüfungen und isolierte Logiktests ausgeführt. Vollständiger Android-Gradle-Build und Android-Gerätetest hier nicht verfügbar.
