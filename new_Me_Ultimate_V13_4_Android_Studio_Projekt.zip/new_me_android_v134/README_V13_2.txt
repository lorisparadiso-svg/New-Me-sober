V13.2 Ultimate Fusion
Android Studio: extract ZIP, open new_me_android_v132, Build > Build APK(s).
App-ID unveraendert: ch.newme.ultimate. versionCode 139.
Original-Daten und 50 Charakterbilder unveraendert, AI 4.0 isoliert in neuem Namespace.
Consent pro Sitzung (Standard aus), separate Bestaetigung vor jeder Aenderung.
Ein direktes Update erfordert dieselbe Signatur wie die aktuell installierte APK.
Vorher ein JSON-Backup exportieren. APK noch nicht in diesem Paket kompiliert.
