V13.3 kostenlose echte Cloudflare Online-KI. Siehe EINRICHTUNG_V13_3.md.
App-ID und lokaler Datenspeicher bleiben wie V13.2. Neue Worker-URL in app/src/main/assets/index.html-Metatag eintragen, dann APK bauen. Keine Zugangsdaten in die App eintragen.
