new Me Ultimate V12.5 - Premium Experience

Open the extracted new_me_android_v125 folder in Android Studio.
Build > Build Bundle(s) / APK(s) > Build APK(s).

Package ID: ch.newme.ultimate (unchanged)
Version: 12.5 / versionCode 128

All prior app views, scripts and localStorage keys are preserved.
The V12.5 patch adds section-based accent colors, smoother navigation,
consistent form controls, keyboard-safe mobile navigation and a bottom sheet
for the existing feature directory. Android Back now closes this sheet first.

No personal data are bundled. Existing Android app data are preserved only
if this APK is installed as an update with matching signing certificate.
Do not uninstall your current app before exporting a backup.

This project was packaged and statically checked, not compiled into an APK
or tested on a physical Samsung device in this environment.
