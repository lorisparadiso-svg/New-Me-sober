New Me Ultimate V11.5

Die Android-App bleibt das WebView-basierte Android-Studio-Projekt.
1. Studio-Ordner new_me_android_v115 oeffnen.
2. Gradle Sync abwarten, Build > Build APK(s).
3. Die APK wurde hier nicht kompiliert oder auf Samsung getestet.
4. Fuer Aktualisierungen bleibt die App-ID ch.newme.ultimate bestehen; die Signatur muss passen.
5. Browser-Daten werden nicht automatisch mit dem Android WebView synchronisiert. Vor dem Wechsel JSON-Backup sichern und in der Android-App importieren.
6. Neue Funktion: zentraler Modul-Manager mit Fokus-Profilen in der bestehenden Daten-Seite.
