# new Me Ultimate V13.3 — kostenlose echte Online-KI

Stand: 23.11.2026. Basis: V13.2 Ultimate Fusion. **Die KI wird erst nach dem Veröffentlichen deines Workers aktiv.** Es wird weder ein KI-Schlüssel noch ein Abo von den App-Nutzern verlangt.

## 1. Cloudflare-Konto (kostenlos) und Worker einrichten

1. Erstelle ein **Cloudflare Workers Free**-Konto: https://dash.cloudflare.com/sign-up. Wähle **keinen bezahlten Tarif**.
2. Installiere **Node.js LTS** (https://nodejs.org/) auf deinem Windows-PC, falls noch nicht vorhanden.
3. Entpacke `new_Me_Ultimate_V13_3_Cloudflare_Worker.zip`, öffne PowerShell im Ordner `newme-v133-cloudflare-worker`.
4. Führe aus:
   ```powershell
   npm install
   npx wrangler login
   npx wrangler d1 create new-me-ultimate-quota
   ```
5. Kopiere die ausgegebene **database_id** (UUID) in die Datei `wrangler.toml`, anstelle von `DEINE-D1-DATABASE-ID-HIER`. Das ist kein geheimer Schlüssel.
6. Datenbanktabellen anlegen:
   ```powershell
   npx wrangler d1 migrations apply new-me-ultimate-quota --remote
   ```
7. Ein privates Salt für anonyme Tageslimits hinterlegen:
   ```powershell
   npx wrangler secret put QUOTA_SALT
   ```
   Du wirst zur Eingabe aufgefordert. Wähle einen langen zufälligen Wert mit mindestens 32 Zeichen, **niemals im HTML oder in der APK speichern**. Diesen Wert brauchen Nutzer nicht.
8. Worker veröffentlichen:
   ```powershell
   npx wrangler deploy
   ```
9. Notiere dir die öffentliche Worker-Adresse, beispielsweise `https://new-me-ultimate-ai.DEIN-NAME.workers.dev`.
10. Öffne diese Adresse mit `/health` am Ende im Browser, beispielsweise `https://new-me-ultimate-ai.DEIN-NAME.workers.dev/health`. Erwartet: `"ok":true`.

## 2. Worker-Adresse einmalig in der App fest eintragen

**Nur du als Entwickler**: In der HTML-Datei suche exakt:

```html
<meta name="newme-ai-worker-url" content="">
```

Ersetze durch deine eigene, echte Worker-Adresse **ohne `/v1/chat` am Ende**, beispielsweise:

```html
<meta name="newme-ai-worker-url" content="https://new-me-ultimate-ai.DEIN-NAME.workers.dev">
```

Wiederhole diese eine Änderung bei:
- `new_Me_Ultimate_V13_3_Free_Online_AI.html` (eigenständige HTML-Version)
- `index.html` **im entpackten PWA-ZIP** (anschliessend Inhalt neu zu einem ZIP packen und bei Netlify deployen)
- `app/src/main/assets/index.html` **im entpackten Android-Studio-Projekt**, **bevor** du die APK baust

**Wichtig:** Der Server-Link ist öffentlich und darf in der App stehen. Er ist **kein API-Key**. Ein geheimer Zugangsschlüssel wird **nirgendwo** in der App eingebaut. Zum Testen kannst du alternativ im KI-Reiter unter "Betreiber-Einrichtung" die Adresse lokal eintragen; diese Test-Einstellung wird nicht beim Export für andere Nutzer mitgeliefert.

## 3. Android-APK bauen

Öffne den Ordner `new_me_android_v133` in Android Studio, lasse den Gradle-Sync durchlaufen und wähle **Build → Build Bundle(s)/APK(s) → Build APK(s)**. Die APK liegt anschliessend unter `app/build/outputs/apk/debug/app-debug.apk`. VersionCode wurde gegenüber V13.2 erhöht, App-ID bleibt `ch.newme.ultimate`.

Vor der Installation alte App-Daten als JSON sichern. **Die alte App nicht deinstallieren.** Ein direktes Upgrade funktioniert nur bei gleicher Signatur wie die bisher installierte APK. Wenn Android `APP_NOT_INSTALLED` meldet, ist möglicherweise die Signatur anders: nicht einfach die alte App löschen, sonst sind die lokalen Daten weg.

## 4. Wie Nutzer die KI verwenden

Die Person öffnet den Hauptreiter **KI-Coach**. Dort ist der echte neue Chat sichtbar. Sie braucht weder Cloudflare-Konto noch API-Key. Für jede Sitzung ist die Zustimmung zur Übermittlung der Chat-Nachrichten nötig.

App-Daten bleiben grundsätzlich auf dem Gerät. Wenn Aufgaben, Training, Tracker, Ziele oder RPG-Level als KI-Kontext gewünscht werden, wird eine konkrete Auswahl getroffen, eine **Vorschau** erstellt und **die nächste Übertragung einmalig bestätigt**. Der Server speichert keine Chats, sondern nur pseudonymisierte Tageslimit-Zähler in D1. Der Cloudflare-Betreiber und Infrastruktur können trotzdem technische Verbindungsmetadaten verarbeiten.

KI-Tipps und Missionsvorschläge ändern nie direkt die App. "Als Mission vorschlagen" oder "Als Ziel vorschlagen" erstellt einen Entwurf im vorhandenen V13.2-Assistenten. Dort muss zunächst die jeweilige Datenkategorie freigegeben sein und erst nach einer weiteren Bestätigung wird gespeichert. XP werden nicht beim Chat oder bei der Entwurfserstellung vergeben.

**Die bisherigen lokalen und alten KI-Werkzeuge sind im einklappbaren Bereich weiterhin vorhanden.** Dort können noch ältere Gemini/Netlify-Einstellungen sichtbar sein. Der **neue** Cloudflare-Chat benötigt diese nicht.

## 5. Schutz und Gratis-Limits

- Cloudflare Workers AI auf **Workers Free**: 10'000 freie AI-Neurons täglich (Kontolimit), keine garantierte Anzahl von Chatnachrichten. Wird die Grenze erreicht, stoppt Cloudflare die KI-Anfragen.
- Dieser Worker limitiert vorsichtig auf **60 Anfragen pro Tag insgesamt**, **12 je IP-Adresse pro Tag** und **2 je IP und Minute**. Bei gemeinsam genutzten Mobilfunk-/WLAN-IP-Adressen teilen Menschen ggf. diese Grenzen.
- IP-Adressen werden mit einem geheimen Salt für den jeweiligen Tag gehasht; D1 hält nur Zähler, keine Nachrichtentexte. Alte Zähler werden täglich bereinigt.
- Beschränkt auf max. 8 Nachrichten pro Anfrage, max. 1400 Zeichen je Nachricht, max. 3000 Zeichen Kontext, max. ca. 420 Ausgabetokens. Verhindert nicht jeden Missbrauch; öffentliche Nutzung ohne Login bleibt angreifbar. Das globale Tageslimit begrenzt Auswirkungen. Bei wachsender Nutzerzahl sollte Turnstile und Nutzerauthentifizierung ergänzt werden.
- Wähle im Cloudflare-Dashboard den Gratisplan. **Nicht** den Paid-Plan aktivieren, wenn du CHF 0 Budget willst. Cloudflare kann Limits oder Modelle ändern; diese Angaben sind keine Preisgarantie.

## 6. Tests und bekannte Grenzen

- Cloudflare-Worker-Kernlogik lokal mit automatisierten Node-Tests und simulierten Cloudflare-Bindings geprüft.
- HTML und ZIP-Struktur statisch geprüft, bestehende `life-reset-v1`-Datenstrukturen unverändert.
- Kein echter Cloudflare-Deploy und keine echte Workers-AI-Anfrage möglich, solange dein Konto nicht verbunden ist.
- Android-Projekt wurde **nicht als APK kompiliert** (Android-SDK/Gradle fehlen in dieser Umgebung); Live-Test auf deinem Samsung ausstehend.

## Hilfreiche offizielle Dokumentation

- Workers AI Binding: https://developers.cloudflare.com/workers-ai/configuration/bindings/
- Workers AI Preise: https://developers.cloudflare.com/workers-ai/platform/pricing/
- D1 Free-Limits: https://developers.cloudflare.com/d1/platform/pricing/
- Wrangler: https://developers.cloudflare.com/workers/wrangler/
