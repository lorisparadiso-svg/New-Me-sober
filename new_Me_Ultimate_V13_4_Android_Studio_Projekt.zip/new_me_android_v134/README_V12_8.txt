V12.8 Stability & Performance
- Android App-ID bleibt ch.newme.ultimate. versionCode 134, versionName 12.8.
- JS/HTML-Integration entspricht PWA und Standalone-Version.
- Export-Bridge begrenzt Base64 vor dem Dekodieren und meldet zu grosse Exporte.
- Fuer ein Update ohne Datenverlust denselben Signaturschluessel wie die installierte APK verwenden.
- APK-Build nicht in der Lieferumgebung ausgefuehrt.
