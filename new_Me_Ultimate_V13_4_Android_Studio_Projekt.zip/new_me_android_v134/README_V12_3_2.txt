new Me Ultimate V12.3.2 - Smooth UX

1. Sicherung aus deiner bisherigen App exportieren.
2. Den Ordner new_me_android_v1232 in Android Studio oeffnen (nicht das ZIP).
3. Gradle Sync ausfuehren, Build > Build APK(s).
4. app/build/outputs/apk/debug/app-debug.apk ueber Google Drive auf das Telefon kopieren.
5. Fuer ein Update muss die APK mit demselben Signaturschluessel signiert sein.

Build: versionCode=125, versionName=12.3.2, applicationId=ch.newme.ultimate (unveraendert).
Daten: localStorage-Schluessel life-reset-v1 unveraendert; keine automatischen Datenloeschungen.
Neue Datum/Uhrzeit-Dialoge existieren nur im Tracking-Schnelleintrag und schreiben erst beim urspruenglichen Speichern.
Rueckgaengig im Tracking-Schnelleintrag setzt nur die gerade geaenderten Felder zurueck; falls sie danach geaendert wurden, wird Undo abgelehnt.

Unvollstaendig: Kein Android-SDK fuer native APK-Kompilierung auf dieser Testmaschine; bitte Android Studio verwenden.
