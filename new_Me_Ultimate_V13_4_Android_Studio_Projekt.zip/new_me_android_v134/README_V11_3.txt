V11.3 – Smart Coach: fünf Coaching-Modi und Opt-in-Kontextvorbereitung im bestehenden KI-Chat. Keine fertige APK; Android Studio / Gradle erforderlich. Vorher Backup sichern.
