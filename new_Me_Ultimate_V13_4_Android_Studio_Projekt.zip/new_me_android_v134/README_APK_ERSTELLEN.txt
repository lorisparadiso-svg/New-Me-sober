new Me Ultimate V11.5 – Android Studio

1. ZIP entpacken. Android Studio öffnen, den Ordner new_me_android_v115 auswählen.
2. Gradle Sync abwarten. Build > Build Bundle(s) / APK(s) > Build APK(s).
3. Fertige Debug-APK: app/build/outputs/apk/debug/app-debug.apk
4. Auf dem Samsung installieren. Vor Datenumzügen JSON-Backup exportieren.

App-ID: ch.newme.ultimate. Datenspeicherung: lokales WebView-Storage, getrennt vom Chrome-Browser.
Bestehende Android-Features aus dem bisherigen Studio-Projekt sind enthalten.
V11.5 neu: kontextbasierter KI-Prompt, adaptive Tagesplanung, Fitness-Auswertung,
Lernfokus, Tagesanalyse, Browser-Snapshots (falls IndexedDB unterstützt).
Für Gemini ist weiterhin eine eigene sichere Konfiguration / Internet nötig.
Kein echter Cloud-Sync, kein garantierter Hintergrundbetrieb.
APK hier nicht kompiliert oder auf Samsung getestet. Gleiche Android-Signatur für Updates erforderlich.

V11.1: Quality Update. Vor dem APK-Wechsel unbedingt JSON-Backup aus der bestehenden App exportieren.

V11.5: KI-Langzeitgedaechtnis, bestaetigte KI-Aktionen, Trainingsprogression, drei Tagesmodi und anpassbares Dashboard.
Zum Sichern vor der Installation ein JSON-Backup exportieren. WebView-Speicher ist vom Chrome-Speicher getrennt.

V12.1: App includes updated offline HTML. Android Studio build still required.
