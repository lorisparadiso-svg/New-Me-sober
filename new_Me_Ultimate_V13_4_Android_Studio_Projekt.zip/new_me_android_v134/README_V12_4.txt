new Me Ultimate V12.4 – Native Experience

Project: new_me_android_v124
Android ID: ch.newme.ultimate (unchanged)
Version: 12.4 / code 126
Storage key: life-reset-v1 (unchanged)

Native changes: Android Back first closes dialogs/overlay or navigates previous in-app page; soft keyboard uses adjustResize; WebView overscroll off; textZoom 100%; optional haptic feedback on navigation or save buttons.

Build: Open this EXTRACTED folder in Android Studio. Build > Build Bundle(s) / APK(s) > Build APK(s). The resulting debug APK typically resides in app/build/outputs/apk/debug/app-debug.apk. Not compiled in this environment.

Do not uninstall the previous app without exporting your data. APK updates require matching signing credentials. Prior user data are not bundled or synchronized automatically.
