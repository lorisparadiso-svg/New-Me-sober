new Me Ultimate V13.4 – Gewohnheiten-Fix
Basis V13.3. Vor dem Update vollständiges JSON-Backup exportieren. Bestehender Speicherschlüssel und App-ID bleiben gleich.
Sober-Zentrale: eigene Substanz, getrennte Startdatum-/Uhrzeit-Eingabe, bearbeiten und löschen mit Bestätigung. Konsum & Gewohnheiten: Startdatum ändern, selbst angegebenen Zeitraum getrennt von dokumentierten Check-ins anzeigen, löschen.
Cloudflare Worker unverändert. Bei bereits eingerichteter Online-KI bisherige öffentliche Worker-URL in den Metatag übernehmen. Android-Projekt ist Quellcode, keine fertige APK.
