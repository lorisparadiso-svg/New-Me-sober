new Me Ultimate V13.1 – Character Evolution 4.0

In Android Studio diesen entpackten Ordner öffnen und Build > Build APK(s) wählen.
Die App-ID bleibt ch.newme.ultimate. Vor Updates Backups erstellen und dieselbe APK-Signatur verwenden.
Neu: Style-Studio mit echter Outfit-Vorschau ohne Speichern, aktualisierbare Ausrüstungssets und individuelle Set-Namen,
levelabhängige Bühnen, Animationen mit Abschaltmöglichkeit, Einstellungen zur Lichtbewegung.
XP, Level, Missionen, die fünf Hauptreiter und 50 Anime-Bilder bleiben aus V13.0 erhalten.
Android-Build nicht garantiert: falls Gradle- oder SDK-Fehler auftreten, Build Output prüfen.
