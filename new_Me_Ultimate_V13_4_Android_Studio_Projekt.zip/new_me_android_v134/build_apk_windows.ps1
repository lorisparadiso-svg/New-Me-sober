# new Me Ultimate V12.3 - erstellt eine DEBUG-APK.
# Voraussetzung: Android Studio, JDK 17, Android SDK Plattform 35.
$ErrorActionPreference = 'Stop'
$Project = Split-Path -Parent $MyInvocation.MyCommand.Path
$GradleVersion = '8.9'
$GradleExe = Join-Path $Project "gradle-$GradleVersion\bin\gradle.bat"
if (!(Test-Path $GradleExe)) {
  Write-Host "Lade Gradle $GradleVersion herunter (Internet erforderlich) ..."
  $Zip = Join-Path $Project "gradle-$GradleVersion-bin.zip"
  Invoke-WebRequest "https://services.gradle.org/distributions/gradle-$GradleVersion-bin.zip" -OutFile $Zip
  Expand-Archive -LiteralPath $Zip -DestinationPath $Project -Force
  Remove-Item $Zip
}
if (!(Test-Path Env:ANDROID_HOME) -and !(Test-Path Env:ANDROID_SDK_ROOT)) {
  $Sdk = Join-Path $env:LOCALAPPDATA 'Android\Sdk'
  if (Test-Path $Sdk) { $env:ANDROID_HOME = $Sdk }
  else { throw 'Android SDK nicht gefunden. Android Studio installieren und SDK Platform 35 installieren.' }
}
if (!(Test-Path Env:JAVA_HOME)) {
  $StudioJbr = 'C:\Program Files\Android\Android Studio\jbr'
  if (Test-Path "$StudioJbr\bin\java.exe") { $env:JAVA_HOME = $StudioJbr }
}
Push-Location $Project
try {
  & $GradleExe --no-daemon assembleDebug
  if ($LASTEXITCODE -ne 0) { throw 'APK-Kompilierung fehlgeschlagen.' }
  $apk = Join-Path $Project 'app\build\outputs\apk\debug\app-debug.apk'
  if (!(Test-Path $apk)) { throw 'Kompilierung abgeschlossen, aber keine APK gefunden.' }
  $Dest = Join-Path $Project 'new-Me-Ultimate-V12.3-debug.apk'
  Copy-Item $apk $Dest -Force
  Write-Host "APK FERTIG: $Dest"
} finally { Pop-Location }
