package ch.newme.ultimate;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.os.Build;
import android.Manifest;
import android.content.pm.PackageManager;
import android.webkit.PermissionRequest;
import android.os.Bundle;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.graphics.Color;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.webkit.DownloadListener;
import android.speech.RecognizerIntent;
import android.util.Base64;
import android.widget.Toast;
import android.annotation.SuppressLint;
import android.content.res.AssetManager;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int PICK_FILE = 801;
    private static final int CREATE_FILE = 802;
    private static final int DICTATE = 803;
    private static final int RECORD_AUDIO_PERMISSION = 804;
    private static final int POST_NOTIFICATION_PERMISSION = 805;
    private String waitingReminderTitle;
    private long waitingReminderMillis;
    private static final String ORIGIN = "appassets.androidplatform.net";
    private WebView web;
    private android.webkit.ValueCallback<Uri[]> fileChooser;
    private byte[] exportBuffer;
    private PermissionRequest pendingAudioRequest;
    private long lastBackPress = 0;

    // New in V10: accept text-only Android shares into the local Life OS entry form.
    // Shared content is not saved automatically; the user must confirm inside the app.
    private String launchUrlForIntent(Intent intent) {
        String url = "https://" + ORIGIN + "/index.html";
        if (intent != null && Intent.ACTION_SEND.equals(intent.getAction())
                && "text/plain".equals(intent.getType())) {
            String text = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (text != null && !text.trim().isEmpty()) {
                if (text.length() > 3000) text = text.substring(0, 3000);
                return url + "?share=" + Uri.encode(text);
            }
        }
        return url;
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (web != null) web.loadUrl(launchUrlForIntent(intent));
    }

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(11, 16, 32));
        getWindow().setNavigationBarColor(Color.rgb(11, 16, 32));
        WebView.setWebContentsDebuggingEnabled(false);
        web = new WebView(this);
        setContentView(web);
        web.setOverScrollMode(android.view.View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHapticFeedbackEnabled(true);
        web.getSettings().setTextZoom(100);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setDatabaseEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(true);  // Needed for files selected through Android picker
        web.getSettings().setAllowFileAccessFromFileURLs(false);
        web.getSettings().setAllowUniversalAccessFromFileURLs(false);
        web.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new Bridge(), "NewMeAndroid");
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                Uri uri = req.getUrl();
                if ("https".equals(uri.getScheme()) && ORIGIN.equals(uri.getHost()) && "/index.html".equals(uri.getPath())) {
                    try { InputStream stream = getAssets().open("index.html");
                          return new WebResourceResponse("text/html", "UTF-8", stream);
                    } catch (IOException e) { return null; }
                }
                return super.shouldInterceptRequest(view, req);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri uri = req.getUrl();
                if ("https".equals(uri.getScheme()) && ORIGIN.equals(uri.getHost())) return false;
                if ("http".equals(uri.getScheme()) || "https".equals(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) { }
                    return true;
                }
                if ("tel".equals(uri.getScheme()) || "mailto".equals(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) { }
                    return true;
                }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    // Grant audio capture only to this app's bundled, trusted HTTPS asset origin.
                    Uri origin = request.getOrigin();
                    boolean trusted = origin != null && "https".equals(origin.getScheme())
                            && ORIGIN.equals(origin.getHost());
                    boolean wantsAudio = false;
                    for (String resource : request.getResources()) {
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) wantsAudio = true;
                    }
                    if (!trusted || !wantsAudio) { request.deny(); return; }
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                    } else {
                        pendingAudioRequest = request;
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, RECORD_AUDIO_PERMISSION);
                    }
                });
            }
            @Override public void onPermissionRequestCanceled(PermissionRequest request) {
                if (pendingAudioRequest == request) pendingAudioRequest = null;
            }
            @Override public boolean onShowFileChooser(WebView v, android.webkit.ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileChooser != null) fileChooser.onReceiveValue(null);
                fileChooser = callback;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, PICK_FILE);
                    return true;
                } catch (Exception e) {
                    android.webkit.ValueCallback<Uri[]> failed = fileChooser;
                    fileChooser = null;
                    if (failed != null) failed.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "Dateiauswahl nicht verfügbar", Toast.LENGTH_SHORT).show();
                    return true;
                }
            }
        });
        web.loadUrl(launchUrlForIntent(getIntent()));
    }
    private void scheduleNativeReminder(String title, long atMillis) {
        if (atMillis <= System.currentTimeMillis() + 30000L || atMillis > System.currentTimeMillis() + 366L*86400000L) {
            Toast.makeText(this, "Bitte eine gültige zukünftige Zeit wählen", Toast.LENGTH_LONG).show(); return;
        }
        AlarmManager alarm = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
        if (alarm == null) { Toast.makeText(this, "Wecker nicht verfügbar", Toast.LENGTH_LONG).show(); return; }
        android.content.SharedPreferences pref = getSharedPreferences("newme_alarms", MODE_PRIVATE);
        int id = pref.getInt("counter", 3000) + 1;
        pref.edit().putInt("counter", id).apply();
        Intent i = new Intent(this, ReminderReceiver.class);
        i.setAction("ch.newme.ultimate.REMIND");
        i.putExtra("title", title);
        i.putExtra("id", id);
        PendingIntent pi = PendingIntent.getBroadcast(this, id, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        // Approximate wake-up alarm; exact alarm permission is intentionally not requested.
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi);
        Toast.makeText(this, "Erinnerung eingeplant (ungefähre Uhrzeit)", Toast.LENGTH_LONG).show();
    }
    private void requestOrSchedule(String title, long atMillis) {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            waitingReminderTitle=title;
            waitingReminderMillis=atMillis;
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, POST_NOTIFICATION_PERMISSION);
        } else scheduleNativeReminder(title, atMillis);
    }
    public final class Bridge {
        @JavascriptInterface public void hapticTick() {
            runOnUiThread(() -> {
                if (web != null && web.isAttachedToWindow())
                    web.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP);
            });
        }

        @JavascriptInterface public void scheduleReminder(String title, long timeMillis) {
            final String safe = title == null ? "New Me Erinnerung" : title.replace("\n", " ").replace("\r", " ").trim();
            if (safe.isEmpty() || safe.length() > 120) return;
            runOnUiThread(() -> requestOrSchedule(safe, timeMillis));
        }
        @JavascriptInterface public void updateWidget(String summary) {
            final String safe = summary == null ? "Heute deine Ziele prüfen" : summary.replace("\n", " ").trim();
            if (safe.length() > 180) return;
            runOnUiThread(() -> {
                getSharedPreferences("newme_widget", MODE_PRIVATE).edit().putString("summary", safe).apply();
                AppWidgetManager manager=AppWidgetManager.getInstance(MainActivity.this);
                ComponentName component=new ComponentName(MainActivity.this,NewMeWidgetProvider.class);
                int[] ids=manager.getAppWidgetIds(component);
                new NewMeWidgetProvider().onUpdate(MainActivity.this,manager,ids);
                Toast.makeText(MainActivity.this,"Widget-Daten aktualisiert",Toast.LENGTH_SHORT).show();
            });
        }
        @JavascriptInterface public void exportFile(String filename, String base64Data, String mime) {
            // Only user-triggered export; avoid arbitrary filesystem permissions.
            try {
                if (base64Data == null || base64Data.length() > 41 * 1024 * 1024) {
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Export zu gross", Toast.LENGTH_LONG).show());
                    return;
                }
                final byte[] decoded = Base64.decode(base64Data, Base64.DEFAULT);
                if (decoded.length > 30*1024*1024) {
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Export zu gross", Toast.LENGTH_LONG).show());
                    return;
                }
                runOnUiThread(() -> {
                    exportBuffer = decoded;
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType(mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
                    i.putExtra(Intent.EXTRA_TITLE, filename == null ? "new-Me-Backup.json" : filename.replace('/', '_').replace('\\', '_'));
                    try { startActivityForResult(i, CREATE_FILE); }
                    catch(Exception e) { exportBuffer = null; Toast.makeText(MainActivity.this, "Speichern nicht verfügbar", Toast.LENGTH_SHORT).show(); }
                });
            } catch(Exception ignored) { }
        }
        @JavascriptInterface public void startDictation() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-CH");
                    startActivityForResult(i, DICTATE);
                } catch (ActivityNotFoundException e) {
                    web.evaluateJavascript("window.newMeReceiveSpeech(null);", null);
                }
            });
        }
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE) {
            if (fileChooser != null) {
                Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                fileChooser.onReceiveValue(result);
                fileChooser = null;
            }
        } else if (requestCode == CREATE_FILE) {
            if (resultCode == RESULT_OK && data != null && data.getData()!=null && exportBuffer!=null) {
                try (OutputStream stream = getContentResolver().openOutputStream(data.getData())) {
                    if (stream != null) stream.write(exportBuffer);
                    Toast.makeText(this, "Datei gespeichert", Toast.LENGTH_SHORT).show();
                } catch(Exception e) { Toast.makeText(this, "Speichern fehlgeschlagen", Toast.LENGTH_SHORT).show(); }
            }
            exportBuffer = null;
        } else if (requestCode == DICTATE) {
            String text = null;
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<String> options = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if(options!=null && !options.isEmpty()) text = options.get(0);
            }
            web.evaluateJavascript("window.newMeReceiveSpeech(" + (text==null ? "null" : JSONObject.quote(text)) + ");", null);
        }
    }
    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(code, permissions, grants);
        if (code == POST_NOTIFICATION_PERMISSION && waitingReminderTitle != null) {
            String title=waitingReminderTitle; long at=waitingReminderMillis;
            waitingReminderTitle=null; waitingReminderMillis=0;
            if (grants.length>0 && grants[0]==PackageManager.PERMISSION_GRANTED) scheduleNativeReminder(title,at);
            else Toast.makeText(this,"Benachrichtigungen nicht erlaubt",Toast.LENGTH_LONG).show();
        }
        if (code == RECORD_AUDIO_PERMISSION && pendingAudioRequest != null) {
            PermissionRequest request = pendingAudioRequest;
            pendingAudioRequest = null;
            if (grants.length > 0 && grants[0] == PackageManager.PERMISSION_GRANTED) {
                request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            } else {
                request.deny();
                Toast.makeText(this, "Mikrofon nicht erlaubt. Textnotizen funktionieren weiterhin.", Toast.LENGTH_LONG).show();
            }
        }
    }
    private void exitOrBrowserBack() {
        if (web != null && web.canGoBack()) { web.goBack(); return; }
        long now = android.os.SystemClock.elapsedRealtime();
        if (now - lastBackPress < 1700) { super.onBackPressed(); return; }
        lastBackPress = now;
        Toast.makeText(this, "Zum Beenden nochmals Zurück drücken", Toast.LENGTH_SHORT).show();
    }
    @Override public void onBackPressed() {
        // V12.4: the embedded UI handles visible dialogs and in-app tab history before exit.
        if (web == null) { exitOrBrowserBack(); return; }
        web.evaluateJavascript("(function(){try{return !!(window.__newMeV1273Clean?.handleAndroidBack?.() || window.__newMeCharacterPlus?.handleAndroidBack?.() || window.__newMeV127?.handleAndroidBack?.() || window.__newMeV126UX?.handleAndroidBack?.() || window.__newMeV125UX?.handleAndroidBack?.() || window.__newMeV124UX?.handleAndroidBack?.())}catch(e){return false}})()", result -> {
            if (!"true".equals(result)) exitOrBrowserBack();
        });
    }
    @Override protected void onDestroy() {
        if(pendingAudioRequest != null) { pendingAudioRequest.deny(); pendingAudioRequest = null; }
        if(fileChooser != null) { fileChooser.onReceiveValue(null); fileChooser=null; }
        if(web!=null) { web.destroy();web=null; }
        super.onDestroy();
    }
}
