package ch.newme.ultimate;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
public class NewMeWidgetProvider extends AppWidgetProvider {
    @Override public void onUpdate(Context context,AppWidgetManager manager,int[] ids) {
        String message=context.getSharedPreferences("newme_widget",Context.MODE_PRIVATE)
                .getString("summary","Tippen, um deine Aufgaben zu öffnen");
        Intent open=new Intent(context,MainActivity.class);
        PendingIntent click=PendingIntent.getActivity(context,0,open,
                PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        for(int id:ids){
            RemoteViews views=new RemoteViews(context.getPackageName(),R.layout.newme_widget);
            views.setTextViewText(R.id.widget_summary,message);
            views.setOnClickPendingIntent(R.id.widget_root,click);
            manager.updateAppWidget(id,views);
        }
    }
}
