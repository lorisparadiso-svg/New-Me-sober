package ch.newme.ultimate;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL="newme_reminders_v101";
    @Override public void onReceive(Context context, Intent intent) {
        String title=intent.getStringExtra("title");
        if(title==null || title.isEmpty()) title="New Me Erinnerung";
        int id=intent.getIntExtra("id",(int)(System.currentTimeMillis()%100000));
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm==null) return;
        if(Build.VERSION.SDK_INT>=26) {
            NotificationChannel channel=new NotificationChannel(CHANNEL,"New Me Erinnerungen", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Von dir bewusst geplante Erinnerungen");
            nm.createNotificationChannel(channel);
        }
        Intent open=new Intent(context,MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent click=PendingIntent.getActivity(context,id,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification notification=new Notification.Builder(context,CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("new Me Ultimate")
            .setContentText(title)
            .setAutoCancel(true).setContentIntent(click).build();
        nm.notify(id,notification);
    }
}
