new Me Ultimate V12.7.1 Character Evolution

Build: Extract ZIP, open the new_me_android_v1271 folder in Android Studio, select Build > Build APK(s).
App ID ch.newme.ultimate UNCHANGED, versionCode 131, versionName 12.7.1.
50 individual anime-style artwork levels are EMBEDDED in the original HTML app, work fully offline.
Character level is read ONLY from legacy XP ledger using floor(xp/200)+1.
No saved data is written by the character display. No duplicate XP, coins, tabs or tasks.
Existing 66-day system, character equipment, shop, tracking and backup remain intact.
50 is a limit on existing artwork, not on XP leveling; XP above level 50 is preserved.
Before installing: backup your data; use matching signing key to update existing app.
APK compilation and native Samsung WebView behavior require testing on your PC/device.
